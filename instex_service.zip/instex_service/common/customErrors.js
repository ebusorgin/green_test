class ValidationError extends Error {
	constructor(...args) {
		super(...args);
		Error.captureStackTrace(this, ValidationError);
	}
}

class PeatioError extends Error {
	constructor(...args) {
		super(...args);
		this.response = args.find(el => el.response && el.response.data).response.data;
		Error.captureStackTrace(this, PeatioError);
	}
}

class ApplogicError extends Error {
	constructor(...args) {
		super(...args);
		this.response = args.find(el => el.response && el.response.data).response.data;
		Error.captureStackTrace(this, ApplogicError);
	}
}

class PaytoolsError extends Error {
	constructor(...args) {
		super(...args);
		this.response = args.find(el => el.response && el.response.data).response.data;
		Error.captureStackTrace(this, PaytoolsError);
	}
}

class BarongError extends Error {
	constructor(...args) {
		super(...args);
		this.response = args.find(el => el.response && el.response.data).response.data;
		Error.captureStackTrace(this, BarongError);
	}
}

class NodelogicError extends Error {
	constructor(...args) {
		super(...args);
		this.response = args.find(el => el.response && el.response.data).response.data;
		Error.captureStackTrace(this, NodelogicError);
	}
}

class DbError extends Error {
	constructor(...args) {
		super(...args);
		Error.captureStackTrace(this, DbError);
	}
}

module.exports = {
	ValidationError,
	PeatioError,
	PaytoolsError,
	BarongError,
	NodelogicError,
	DbError,
	ApplogicError
};
