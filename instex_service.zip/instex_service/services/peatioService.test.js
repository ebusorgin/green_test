// const mockAxios = require('axios');
const { JWS, JWK } = require('jose')
const peatioService = require('./peatioService');

// mocks
const axios = require('axios');
jest.mock('axios')

test.skip('getMarkets to fetch markets properly', async () => {
    expect.assertions(1);
    axios.mockImplementationOnce(request => {
        return Promise.resolve(request);
    })
    const request = await peatioService.getMarkets();
    expect(request).toStrictEqual({
        url: `${process.env.PEATIO_URL}/api/v2/public/markets`,
        method: 'GET',
    })
    // const markets = (await peatioService.getMarkets());
    // expect(markets).toBeDefined();
    // expect(Array.isArray(markets)).toBeTruthy();
    // expect(markets.length).toBeDefined();
    // expect(markets.length).toBeGreaterThan(0);
})

test.skip('getCurrencies to fetch currencies properly', async () => {
    expect.assertions(1);
    axios.mockImplementationOnce(request => {
        return Promise.resolve(request);
    })
    const request = await peatioService.getCurrencies();
    expect(request).toStrictEqual({
        url: `${process.env.PEATIO_URL}/api/v2/public/currencies`,
        method: 'GET',
    })
    // const currencies = (await peatioService.getCurrencies());
    // expect(currencies).toBeDefined();
    // expect(Array.isArray(currencies)).toBeTruthy();
    // expect(currencies.length).toBeDefined();
    // expect(currencies.length).toBeGreaterThan(0);
})

test.skip('cookTransfer to correctly prepare input for transfer', () => {
    const fiatTransfer = peatioService.cookTransfer({ currencyId: 'usd', currencyType: 'fiat', amount: 100, uid: 'ID123' });
    const coinTransfer = peatioService.cookTransfer({ currencyId: 'eth', currencyType: 'coin', amount: 200, uid: 'ID321' });

    expect(fiatTransfer).toStrictEqual({
        currency: 'usd',
			amount: '1e+2',
			account_src: {
				code: 301,
			},
			account_dst: {
				code: 201,
				uid: 'ID123',
			}
    });

    expect(coinTransfer).toStrictEqual({
        currency: 'eth',
			amount: '2e+2',
			account_src: {
				code: 302,
			},
			account_dst: {
				code: 202,
				uid: 'ID321',
			}
    });
})

test.skip('createTransaction to send a correct JWS request', async () => {
    expect.assertions(1);
    axios.mockImplementationOnce(request => {
        return Promise.resolve(request);
    })
    const jwtPublicKey = Buffer.from(process.env.JWT_PUBLIC_KEY, 'base64').toString('utf-8');
    const jwk = JWK.asKey(jwtPublicKey, { alg: 'RS256', kid: process.env.JWT_ISSUER || 'applogic', use: 'sig' }); 
    const request = await peatioService.createTransfer({ currencyId: 'usd', currencyType: 'fiat', type: 'trade', amount: 100, uid: 'ID123' });
    const decodedPayload = JWS.verify(request.data, jwk);
    expect(decodedPayload.data["operations"]).toStrictEqual(
         [
          {
            "currency": "usd",
            "amount": "1e+2",
            "account_src": {
              "code": 301
            },
            "account_dst": {
              "code": 201,
              "uid": "ID123"
            }
          }
        ]
    );
})

test.skip('bulkCreateTransaction to send a correct JWS request', async () => {
    expect.assertions(1);
    axios.mockImplementationOnce(request => {
        return Promise.resolve(request);
    })
    const jwtPublicKey = Buffer.from(process.env.JWT_PUBLIC_KEY, 'base64').toString('utf-8');
    const jwk = JWK.asKey(jwtPublicKey, { alg: 'RS256', kid: process.env.JWT_ISSUER || 'applogic', use: 'sig' }); 

    const operations = [
        {currencyId: 'eth', currencyType: 'coin', amount: 100, uid: 'ID123'},
        {currencyId: 'usd', currencyType: 'fiat', amount: 200, uid: 'ID321'}
    ]

    const request = await peatioService.bulkCreateTransfer(operations);
    const decodedPayload = JWS.verify(request.data, jwk);
    expect(decodedPayload.data["operations"]).toStrictEqual(
        [
            {
                currency: 'eth',
                amount: '1e+2',
                account_src: { code: 302 },
                account_dst: { code: 202, uid: 'ID123' }
            },
            {
                currency: 'usd',
                amount: '2e+2',
                account_src: { code: 301 },
                account_dst: { code: 201, uid: 'ID321' }
            }
        ]
    );
}) 
