const axios = require('axios');
const JWTHandler = require('../lib/JWTHandler');
const { BarongError } = require('../common/customErrors');
const User = require('../models/user.js');

const barongJwtPrivateKey = Buffer.from(process.env.BARONG_JWT_PRIVATE_KEY, 'base64').toString('utf-8');
class BarongService {
    static async request(data, method, url) {
        const token = JWTHandler.signPayload(data);

        const req = {
            url,
            method,
            headers: {
                'Content-Type': 'application/json'
            },
            data: token,
        }
        
        let res;

        try {
            res = await axios(req); 
        } catch (err) {
            throw new BarongError(err);
        }
    
        return res;
    }

    static async createSession(uid) {
        const user = (await User.find({uid}))[0];
        if(!user) throw new Error("User not found");

        return BarongService.signSession({
            uid: user.uid,
            email: user.email,
            role: user.role,
            level: user.level,
            state: user.state,
            referral_id: user.referral_id,
            sub: "session",
        });
    }

    static signSession(session) {
        const token = JWTHandler.createToken(session, barongJwtPrivateKey, "barong");
        return `Bearer ${token}`;
	}
}

module.exports = BarongService;
