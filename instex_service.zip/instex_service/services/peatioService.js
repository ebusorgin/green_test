const axios = require('axios');
const JWTHandler = require('../lib/JWTHandler');
const { PeatioError } = require('../common/customErrors');
const BarongService = require('./barongService');
const User = require('../models/user.js');

const maxTries = 5;
class PeatioService {
	static async request(data, method, url, headers) {
		const token = JWTHandler.signPayload(data);

		const req = {
			url,
			method,
			headers: {
				'Content-Type': 'application/json',
			},
			data: token,
		};

		if(headers) req.headers = { ...req.headers, ...headers };

		try {
			let res = await axios(req);
			return res.data;
		} catch (err) {
			throw new PeatioError(err);
		}
	}

	static async getMarkets(params) {
		const req = {
			url: `${process.env.PEATIO_URL}/api/v2/public/markets`,
			method: 'GET',
		};
		if(params) req.params = params;

		let count = 0;
		while(true) {
			try {
				let res = await axios(req);
				return res.data;
			} catch (err) {
				if (++count == maxTries) throw new PeatioError(err);
			}
		}
	}

	static async getCurrencies() {
		const req = {
			url: `${process.env.PEATIO_URL}/api/v2/public/currencies`,
			method: 'GET',
		};

		let count = 0;
		while(true) {
			try {
				let res = await axios(req);
				return res.data;
			} catch (err) {
				if (++count == maxTries) throw new PeatioError(err);
			}
		}
	}

	static async getDepth(market) {
		const req = {
			url: `${process.env.PEATIO_URL}/api/v2/public/markets/${market}/depth`,
			method: 'GET',
		};

		let count = 0;
		while(true) {
			try {
				let res = await axios(req);
				return res.data;
			} catch (err) {
				if (++count == maxTries) throw new PeatioError(err);
			}
		}
	}

	static async createOrder(params) {
		const {
			session, market, side, volume, ord_type, price
		} = params;

		const data = {
			market,
			side,
			volume : `${volume}`,
      ord_type
		};

		const req = {
			url : `${process.env.PEATIO_URL}/api/v2/market/orders`,
			method : "POST",
			headers: {
				'Content-Type': 'application/json',
				'Authorization' : session
			},
			data,
		};

		try {
			let res = await axios(req);
			return res.data;
		} catch (err) {
			throw new PeatioError(err);
		}
  }
}

module.exports = PeatioService;
