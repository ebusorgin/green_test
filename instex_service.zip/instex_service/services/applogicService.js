const axios = require('axios');
const JWTHandler = require('../lib/JWTHandler');
const { ApplogicError } = require('../common/customErrors');
const BarongService = require('./barongService');
const User = require('../models/user.js');

const maxTries = 5;
class ApplogicService {
	static async request(data, method, url, headers) {
		const token = JWTHandler.signPayload(data);

		const req = {
			url,
			method,
			headers: {
				'Content-Type': 'application/json',
			},
			data: token,
		};

		if(headers) req.headers = { ...req.headers, ...headers };

		try {
			let res = await axios(req);
			return res.data;
		} catch (err) {
			throw new ApplogicError(err);
		}
	}

	static async createOrder(params) {
		const { uid, quote_unit, contribution, sale } = params;
		
		const user = (await User.find({uid}))[0];
		if(!user) throw new Error("User not found");
		
		const session = { 
			uid: user.uid,
			email: user.email,
			role: user.role,
			level: user.level,
			state: user.state,
			referral_id: user.referral_id,
			sub: "session",
		};

		const signedSession = BarongService.signSession(session);

		const data = { contribution, quote_unit, sale };

		const req = {
			url : `${process.env.APPLOGIC_URL}/api/v2/private/ieo/orders`,
			method : "POST",
			headers: {
				'Content-Type': 'application/json',
				'Authorization' : signedSession
			},
			data,
		};

		try {
			let res = await axios(req);
			return res.data;
		} catch (err) {
			throw new ApplogicError(err);
		}
	}
}

module.exports = ApplogicService;
