// const mockAxios = require('axios');
const { JWS, JWK } = require('jose')
const nodelogicService = require('./nodelogicService');

const axios = require('axios');
jest.mock('axios')

test.skip('getParents to fetch markets properly', async () => {
    expect.assertions(1);
    axios.mockImplementationOnce(request => {
        return Promise.resolve({
            data: {
                initRequest: request,
            }
        });
    })
    const jwtPublicKey = Buffer.from(process.env.JWT_PUBLIC_KEY, 'base64').toString('utf-8');
    const jwk = JWK.asKey(jwtPublicKey, { alg: 'RS256', kid: process.env.JWT_ISSUER || 'applogic', use: 'sig' }); 
    const request = await nodelogicService.getParents('ID123');
    const decodedPayload = JWS.verify(request.initRequest.data, jwk);
    expect(decodedPayload.data).toStrictEqual({
        uid: 'ID123',
    })
})
