const JWTHandler = require('../lib/JWTHandler');
const { NodelogicError } = require('../common/customErrors');
const axios = require('axios');

class NodelogicService {
	static async request(data, method, url) {
		const maxTries = 5;
		const token = JWTHandler.signPayload(data);

		const req = {
			url,
			method,
			headers: {
				'Content-Type': 'application/json',
			},
			data: token,
		};
		
		let count = 0;
		while(true) {
			try {
				let res = await axios(req);
				return res.data;
			} catch (err) {
				if (++count == maxTries) throw new NodelogicError(err);
			}
		}		
	}

	static async getParents(uid, depth) {
		if (process.env.LOCAL === '1') return {
			email : 'kirill.pahl@digiwrld.com',
			parents : [
				{
					uid : "ID40BAB42B1F",
					email: 'kvpal@mail.ru'
				},
				{
					uid : "ID7F380E34CA",
					email: 'admin@barong.io'
				}
			]
		}
		
		return await this.request({uid, depth}, 'POST', `${process.env.NODELOGIC_URL}/api/v2/management/getParents`)
	}
}

module.exports = NodelogicService;
