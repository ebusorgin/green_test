const JWTHandler = require('../lib/JWTHandler');
const { PaytoolsError } = require('../common/customErrors');
const axios = require('axios');
const {ValidationError} = require("../common/customErrors");

const maxTries = 5;
class PaytoolsService {
	static async request(data, method, url) {
		const token = JWTHandler.signPayload(data);

		const req = {
			url,
			method,
			headers: {
				'Content-Type': 'application/json',
			},
			data: token,
		};
			let res = await axios(req);
			return res;

	}

	static async initializePayin({session, currencyId, amount, ipaddress, redirectUrl, need_deposit_fee}) {
		const data = {
			need_deposit_fee,
            session,
            currencyId,
            amount,
			ipaddress,
			redirectUrl
		};
		const method = 'POST';
		const url = `${process.env.PAYTOOLS_URL}/api/v1/management/payin/new`;
        let res

            res = await this.request(data, method, url);
            return res.data;





	}

    static async PaymentToCard(data) {
        console.log("SERVICE START",data)
        const method = 'POST';
        const url = `${process.env.PAYTOOLS_URL}/api/v1/management/payment_to_card`;

        let res = await this.request(data, method, url);
        console.log("SERVICE ",res.data)
        return res;
    }
	static async handleRedirect(data) {
		const method = 'POST';
		const url = `${process.env.PAYTOOLS_URL}/api/v1/management/handleRedirect`;
		
		let res = await this.request(data, method, url);
		return res;
  }

    static async createPaymentToCard(data){

    }
  static async createDeposit({
    uid,
    currency,
    amount,
    state = 'accepted',
    need_deposit_fee = true
  }) {
   	const data = {
      uid,
      currency,
      amount,
      z_type: 1,
      need_deposit_fee,
    };
    const method = 'POST';
    const url = `${process.env.PAYTOOLS_URL}/api/v1/management/deposit/new`;


      try {
          let res = await this.request(data, method, url).catch(err=>{
          console.log('ERROR createDeposit',err)
      });
      return res.data;
   } catch (error) {
        console.log('ERROR createDeposit',error)
      throw new PaytoolsError(error)
    }
  }


  static async updateDeposit(payload) {
    const method = 'POST';
    const url = `${process.env.PAYTOOLS_URL}/api/v1/management/deposit/update_state`;

    try {
      let res = await this.request(payload, method, url);
      return res.data;  	 
    } catch (error) {
      throw new PaytoolsError(error)
    }
  }
}

module.exports = PaytoolsService;
