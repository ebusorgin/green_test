// Models


const Order             = require('../models/order');
const OrderIeo          = require('../models/orderIeo');
const Purchase          = require('../models/purchase');
const axios             = require('axios');
const crypto             = require('crypto');
const {exec} = require('child-process-promise');
const querystring = require('querystring');
// Services
const PaytoolsService   = require('../services/paytoolsService');

// Lib
const Redis             = require("../lib/redis")

// Common
const { PaytoolsError } = require("../common/customErrors");
const peatioService = require('../services/peatioService');

const redirect_url_base     = `${process.env.SELF_URL}/api/v2/instex/private/orders`;
const debugLevel            = process.env.DEBUG_LEVEL;
const logger = require('../lib/logger')
const db = require('../lib/db');
const api_key = process.env.ADMIN_API_KEY;
const api_secret = process.env.ADMIN_SECRET;


class InstexService {
    static async checkReversal(payload) {
        let {amount, uid } = payload;
        console.log(amount, uid )
        let result  = await db.query(`
        select * from instex_service.reversal where uid='${uid}' `)
        if (result&&result.length>0&&result[0].amount>0) {
            let newamount = amount - (amount * (3.2 / 100) + 0.1);
            let newreversal = result[0].amount - newamount

            const nonce = Date.now();
            const sig = this.getSignature(nonce);
            if (result[0].amount - amount > 0) {
                //return order
                await db.query(`update  instex_service.reversal SET amount='${result[0].amount -newamount}' where uid='${uid}'`)
                await db.query(`insert into instex_service.reversal_logs (uid,amount,type) VALUES ('${payload.uid}','${newamount}','adjustments') `)
                let str = ``
                str += `curl --location --request POST ${process.env.SELF_URL}/api/v2/peatio/admin/adjustments/new `
                str += `--silent `
                str += `--verbose `
                str += `--header "X-Auth-Apikey: ${api_key}" `
                str += `--header "X-Auth-Nonce: ${nonce}" `
                str += `--header "X-Auth-Signature: ${sig}"  `
                str += `--header "Content-Type: application/json" `
                str += `-d  '{"amount":"-${newamount}", "asset_account_code":"101","category":"misc","currency_id":"eur","description":"","reason":"reversal","receiving_account_code":"201","receiving_member_uid":"${uid}"}'`
                let processData = querystring.parse(await this.setReq(str));

                if (JSON.parse(Object.keys(processData)[0]).hasOwnProperty('id')) {

                    str = ``
                    str += `curl --location --request POST ${process.env.SELF_URL}/api/v2/peatio/admin/adjustments/action `
                    str += `--silent `
                    str += `--verbose `
                    str += `--header "X-Auth-Apikey: ${api_key}" `
                    str += `--header "X-Auth-Nonce: ${nonce}" `
                    str += `--header "X-Auth-Signature: ${sig}"  `
                    str += `--header "Content-Type: application/json" `
                    str += `-d  '{"action":"accept", "id":"${JSON.parse(Object.keys(processData)[0]).id}"}'`
                    let reuslt = querystring.parse(await this.setReq(str));

                }
                return 0
            } else {
                //continue order
                await db.query(`update  instex_service.reversal SET amount='0' where uid='${uid}'`)
                await db.query(`insert into instex_service.reversal_logs (uid,amount,type) VALUES ('${payload.uid}','${result[0].amount}','adjustments') `)

                let str = ``
                str += `curl --location --request POST ${process.env.SELF_URL}/api/v2/peatio/admin/adjustments/new `
                str += `--silent `
                str += `--verbose `
                str += `--header "X-Auth-Apikey: ${api_key}" `
                str += `--header "X-Auth-Nonce: ${nonce}" `
                str += `--header "X-Auth-Signature: ${sig}"  `
                str += `--header "Content-Type: application/json" `
                str += `-d  '{"amount":"-${result[0].amount}", "asset_account_code":"101","category":"misc","currency_id":"eur","description":"","reason":"reversal","receiving_account_code":"201","receiving_member_uid":"${uid}"}'`
                let processData = querystring.parse(await this.setReq(str));

                if (JSON.parse(Object.keys(processData)[0]).hasOwnProperty('id')) {

                    str = ``
                    str += `curl --location --request POST ${process.env.SELF_URL}/api/v2/peatio/admin/adjustments/action `
                    str += `--silent `
                    str += `--verbose `
                    str += `--header "X-Auth-Apikey: ${api_key}" `
                    str += `--header "X-Auth-Nonce: ${nonce}" `
                    str += `--header "X-Auth-Signature: ${sig}"  `
                    str += `--header "Content-Type: application/json" `
                    str += `-d  '{"action":"accept", "id":"${JSON.parse(Object.keys(processData)[0]).id}"}'`
                    let reuslt = querystring.parse(await this.setReq(str));

                    return Math.abs(newamount-result[0].amount)
                }
            }
            return amount
        }else{
            return amount
        }

    }
    static async initializeCcPurchase({session, payload, ipaddress}) {
        const { outcomeCurrencyId, incomeCurrencyId, amount, style, sale_id } = payload;
        let need_deposit_fee;
        if (sale_id) {
           const ieo = (await axios.get(`${process.env.APPLOGIC_URL}/api/v2/public/ieo/sales/${sale_id}`)).data;
           need_deposit_fee = ieo.need_deposit_fee;
        }

        const { url, tid } = await PaytoolsService.initializePayin({
            need_deposit_fee,
            session,
            currencyId : outcomeCurrencyId,
            amount,
            ipaddress,
            redirectUrl: `${redirect_url_base}?sell_amount=${amount}&sell_currency=${outcomeCurrencyId}&buy_amount=null&buy_currency=${incomeCurrencyId}&style=${style}`
        })

        if(!url || !tid) throw new Error("Error initializing payment");

        // Purchase create in DB
        await Purchase.insert({
            uid: session.uid,
            tid,
            sale_id,
            outcome_currency_id: outcomeCurrencyId,
            income_currency_id: incomeCurrencyId,
            type: "ccPurchase",
            status: "ccInit"
        });

        // Purchase create in Redis
        await Redis.setAsync(`instex:deposit:${tid}`, "ccInit");

        return { url, tid };
    }

    static async initializeReversal({session, payload, ipaddress}) {

        const { outcomeCurrencyId, incomeCurrencyId, amount, style } = payload;

        const order = await this.createOrder({
            uid: session.uid,
            amount,
            outcome_currency_id: outcomeCurrencyId,
            income_currency_id: incomeCurrencyId,
        });

        const url = `${redirect_url_base}/${order.id}?sell_amount=${amount}&sell_currency=${outcomeCurrencyId}&buy_amount=${order.origin_volume}&buy_currency=${incomeCurrencyId}&style=${style}`;
        return url;
    }
    static async initializeInstPurchase({session, payload, ipaddress}) {
      const { outcomeCurrencyId, incomeCurrencyId, amount, style } = payload;
      
      const order = await this.createOrder({
          uid: session.uid,
          amount,
          outcome_currency_id: outcomeCurrencyId,
          income_currency_id: incomeCurrencyId,
      });

      const url = `${redirect_url_base}/${order.id}?sell_amount=${amount}&sell_currency=${outcomeCurrencyId}&buy_amount=${order.origin_volume}&buy_currency=${incomeCurrencyId}&style=${style}`;
      return url;
    }
    static async setReq(command) {
        return (await exec(command)).stdout
    }
    static async initializeTransfer({ payload }) {
      const { uid, incomeCurrencyId, outcomeCurrencyId, amount } = payload;

      if (incomeCurrencyId !== 'usdt' || outcomeCurrencyId !== 'eur') throw new Error('Сurrency is not supported')

      const hasMarkets = await InstexService.hasMarkets(incomeCurrencyId, outcomeCurrencyId);
      if (!hasMarkets){
        throw new Error('No available markets')
      }

      let deposit

        deposit = await PaytoolsService.createDeposit({
          uid,
          currency: outcomeCurrencyId,
          amount
        })

        if (deposit.state !== 'submitted') throw new Error('Deposit not submitted');

        deposit = await PaytoolsService.updateDeposit({ tid: deposit.tid, state: 'accepted' })

        logger.log({ level: 'info', message: deposit, type: 'deposit' })
        let reversal = await this.checkReversal(payload).catch(err=>{
            console.log(err)
        })
        if (reversal === 0) {












            throw new Error('accept pay reversal ')
        } else {
            console.log('payload.amount = reversal',reversal)
            deposit.amount = reversal
        }
        try {
        const order = await this.createOrder({
            uid: uid,
            amount: deposit.amount,
            outcome_currency_id: outcomeCurrencyId,
            income_currency_id: incomeCurrencyId,
        });

        logger.log({ level: 'info', message: order, type: 'order' })
  
        return order;
         } catch (error) {
        throw new Error(error)
      }
    }
    static getSignature(nonce) {
        return crypto
            .createHmac('sha256', api_secret)
            .update(`${nonce}${api_key}`)
            .digest('hex');
    }
    static async defineAndCreateOrderByType(addToOrderCompletedHandlers, {
      uid,
      amount,
      outcome_currency_id,
      income_currency_id,
      tid
    }) {

      const hasStreightMarket = await InstexService.hasMarkets(income_currency_id, outcome_currency_id);

      if (hasStreightMarket) {
        const order = await this.createOrder({
          uid,
          amount,
          outcome_currency_id,
          income_currency_id,
          tid
        });

        return;
        
      } else {
        const hasSequentialMarket = await InstexService.hasMarkets(income_currency_id, 'usdt') && await InstexService.hasMarkets('usdt', outcome_currency_id);

        if (hasSequentialMarket) {

          let first, second;
          try {
            first = await this.createMarketOrder(addToOrderCompletedHandlers, {
              uid,
              amount,
              outcome_currency_id,
              income_currency_id: 'usdt',
              tid,
            }, 'ccPurchase');
      
            second = await this.createMarketOrder(addToOrderCompletedHandlers, {
              uid,
              amount: first.initial_income_amount,
              outcome_currency_id: 'usdt',
              income_currency_id,
              tid,
            }, 'instPurchase');

          } catch (error) {
            throw new Error("Error in seq order creation", error);
          }

          return;
        }
      }

      throw new Error("No available markets");
    }

    static async createMarketOrder(addToOrderCompletedHandlers, {uid, amount, outcome_currency_id, income_currency_id, tid}, type) {
      const orderBuilder = new Order({uid, amount, outcome_currency_id, income_currency_id})
      let order;
      try {
          order = await orderBuilder.create();
           // // Wait for msg .order_completed from RabbiyMQ
          order = await new Promise((resolve, reject) => {
            addToOrderCompletedHandlers({ id: order.id, resolve })
          })
      } catch (e) {
          if(tid) {
              Purchase.update({status: "orderFailure"}, {uid, tid});
              await Redis.delAsync(`instex:deposit:${tid}`);
          }

          throw new Error(e);
      }

      if (tid) {
        await Purchase.update({status: "orderComplete", order_id: order.id}, {uid, tid});
        await Redis.delAsync(`instex:deposit:${tid}`);
      } else {
          await Purchase.insert({uid, order_id: order.id, status: "orderComplete", type }); // type ccPurchase | instPurchase
      }

      // Redis.setAsync(`instex:order:${order.id}`, "orderInit"); // Currently logic for market orders not clear. Peatio does not throw an event on market order completion.
      return order;
    }

    static async hasMarkets(incomeCurrencyId, outcomeCurrencyId) {
      let markets = await peatioService.getMarkets({
        base_unit : `${incomeCurrencyId}`,
        quote_unit : `${outcomeCurrencyId}`
      });
      markets = markets.filter(el => el.id === `${incomeCurrencyId}${outcomeCurrencyId}`);

      if(!markets.length) {
          markets = await peatioService.getMarkets({
              quote_unit : `${incomeCurrencyId}`,
              base_unit : `${outcomeCurrencyId}`
          });
          markets = markets.filter(el => el.id === `${incomeCurrencyId}${outcomeCurrencyId}`);
      }
      
      return !!markets.length;
    }   

    static async handleMessageDeposit(event, addToOrderCompletedHandlers) {
      const message = event.record;
      if(!message) return
      if(!(await Redis.getAsync(`instex:deposit:${message.tid}`))) return;
      
      switch (message.state) {
          case "accepted" : {
              await Purchase.update({status: "ccAccepted"}, {uid: message.user.uid, tid: message.tid});
              const purchase = (await Purchase.find({uid: message.user.uid, tid: message.tid}))[0];
              if (!purchase) throw new Error(`Desync between Redis and DB. TID = ${message.tid}`);

              if (purchase.sale_id) {
                  await this.createIeoOrder({
                      uid: message.user.uid,
                      sale: purchase.sale_id,
                      amount: parseFloat(message.amount),
                      outcome_currency_id: purchase.outcome_currency_id,
                      tid: purchase.tid
                  })
              } else {

                  await this.defineAndCreateOrderByType(addToOrderCompletedHandlers, {
                    uid: message.user.uid,
                    amount: parseFloat(message.amount),
                    outcome_currency_id: purchase.outcome_currency_id,
                    income_currency_id: purchase.income_currency_id,
                    tid: purchase.tid
                  })
              }

              break;
          }

          default : {
              await Purchase.update({status: "ccDeclined"}, {uid: message.user.uid, tid: message.tid});
              break;
          }
      }

      await Redis.delAsync(`instex:deposit:${message.tid}`);
    }

    static async createOrder({uid, amount, outcome_currency_id, income_currency_id, tid}) {
        const orderBuilder = new Order({uid, amount, outcome_currency_id, income_currency_id})
        let order;
        try {
            order = await orderBuilder.create();
        } catch (e) {
            if(tid) {
                Purchase.update({status: "orderFailure"}, {uid, tid});
                await Redis.delAsync(`instex:deposit:${tid}`);
            }

            throw new Error(e.message);
        }

        if(tid) {
            await Purchase.update({status: "orderComplete", order_id: order.id}, {uid, tid});
            await Redis.delAsync(`instex:deposit:${tid}`);
        } else {
            await Purchase.insert({uid, order_id: order.id, status: "orderComplete", type: "instPurchase"});
        }

        // Redis.setAsync(`instex:order:${order.id}`, "orderInit"); // Currently logic for market orders not clear. Peatio does not throw an event on market order completion.
        return order;
    }

    static async createIeoOrder({uid, sale, amount, outcome_currency_id, tid}) {
        const orderBuilder = new OrderIeo({uid, sale, amount, outcome_currency_id})
        const order = await orderBuilder.createWithId();

        if(tid) {
            await Purchase.update({status: "orderComplete", order_id: order.id}, {uid, tid});
        } else {
            await Purchase.insert({uid, order_id: order.id, status: "orderComplete", type: "instPurchase"});
        }

        await Redis.delAsync(`instex:deposit:${tid}`);
        await Redis.setAsync(`instex:orderIeo:${order.id}`, "orderInit");

        return order;
    }

    // Currently logic for market orders not clear. Peatio does not throw an event on market order completion.
    static async handleMessageOrder(message) {        
        if(!(await Redis.getAsync(`instex:order:${message.id}`))) return;

        await Purchase.update({status: "orderComplete"}, {uid: message.user.uid, order_id: message.tid});
        await Redis.delAsync(`instex:order:${message.id}`);
    }
    
    static async handleMessageIeoOrder(event) {
      const message = event.record;
      if(!(await Redis.getAsync(`instex:orderIeo:${message.id}`))) return;

      switch (message.state) {
          case "purchased" : {
              await Purchase.update({status: "orderComplete" }, {
                  uid: message.uid,
                  order_id: message.id
              });
              break;
          }

          default : {
              await Purchase.update({status: "ccDeclined"}, {uid: message.uid, order_id: message.id});
              break;
          }
      }

      await Redis.delAsync(`instex:orderIeo:${message.id}`);
    }

    static async getCcPurchaseState({tid, session}) {
        // TODO: encrypt orderId
        // const bytes = CryptoJS.AES.decrypt(base64url.decode(orderId), aesKey);
        // const orderId = bytes.toString(CryptoJS.enc.Utf8);

        const { uid } = session;
        const purchase = await Purchase.find({tid});

        if (purchase[0].uid !== uid) throw new Error('Access denied');

        return purchase.state;
    }

    static async getPurchase({tid, order_id, session}) {
        // TODO: encrypt orderId
        // TODO: Put IEO logic in a separate method
        // const bytes = CryptoJS.AES.decrypt(base64url.decode(orderId), aesKey);
        // const orderId = bytes.toString(CryptoJS.enc.Utf8);
        let purchase;
        const { uid } = session;
        if (!tid && !order_id) throw new Error("Not tid or order_id specified");

        const order = await Purchase.findSale({tid, order_id, uid});

        if (order.sale_id) purchase = await Purchase.findWithIeo({tid, order_id});
        else purchase = await Purchase.find({tid, order_id});

        const raw = purchase[0];
        if (raw.uid !== uid) throw new Error('Access denied');
        const fee = !order.sale_id && raw.taker_fee ? (parseFloat(raw.origin_volume) * parseFloat(raw.taker_fee)) : 0;
        const volume = order.sale_id ? parseFloat(raw.tokens_locked) * 2 /*It's Chatello logic*/ : parseFloat(raw.origin_volume);

        return order.sale_id ? {
            id: raw.id,
            uid: raw.uid,
            tid: raw.tid,
            sale_id: raw.sale_id,
            outcome_currency_id: raw.outcome_currency_id,
            income_currency_id: raw.income_currency_id,
            status: raw.status,
            origin_volume: volume,
        } : {
            id: raw.id,
            uid: raw.uid,
            tid: raw.tid,
            order_id: raw.order_id,
            outcome_currency_id: raw.outcome_currency_id,
            income_currency_id: raw.income_currency_id,
            status: raw.status,
            origin_volume: volume,
            fee: fee
        }
    }


}

module.exports = InstexService;
