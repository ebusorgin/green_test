const db = require('../lib/db');
const _ = require('lodash');

const peatio = `${process.env.DB_PREFIX ? process.env.DB_PREFIX + '-' : ''}peatio_production`;
const applogic = 'applogic_logic_production';
const schema = 'instex_service';
const table = 'orders';

class Purchase {
  static async insert(fields) {
    const keys = [];
    const values = []
    Object.entries(fields).forEach(([key, value]) => {
        if(!!value) {
            keys.push(key);
            values.push(typeof(value) === 'number' ? value : `'${value}'`);
        }
    })
    const result = await db.query(`INSERT INTO \`${schema}\`.\`${table}\`(${keys}) VALUES (${values})`);
    return result;
  }

  static async find(conditions, limit = 10, offset = 0) {
    const conditionString = Object.entries(conditions)
        .filter(([key, value]) => !!value)
        .map(([key, value], index) => {
          if (!Array.isArray(value)) value = [value];
          value = value.map(el => typeof(el) === 'number' ? el : `'${el}'`);
          return `${index === 0 ? '' : 'AND '}\`${key}\` IN (${value})`;
        }).join(' ');
    const whereString = conditionString ? `WHERE ${conditionString}` : '';
    const result =  await db.query(`
                           SELECT p.id,
                             p.uid,
                             p.tid,
                             p.order_id,
                             p.sale_id,
                             p.outcome_currency_id,
                             p.income_currency_id,
                             p.status,
                             o.origin_volume,
                             o.taker_fee
                           FROM \`${schema}\`.\`${table}\` p
                           LEFT JOIN \`${peatio}\`.\`orders\` o
                           ON p.order_id = o.id
                           ${whereString}
                           LIMIT ${limit} OFFSET ${offset}
                            ;`);
    return result;
  }

  static async findWithIeo(conditions, limit = 10, offset = 0) {
    const conditionString = Object.entries(conditions)
        .filter(([key, value]) => !!value)
        .map(([key, value], index) => {
          if (!Array.isArray(value)) value = [value];
          value = value.map(el => typeof(el) === 'number' ? el : `'${el}'`);
          return `${index === 0 ? '' : 'AND '}\`${key}\` IN (${value})`;
        }).join(' ');
    const whereString = conditionString ? `WHERE ${conditionString}` : '';

    const result =  await db.query(`
                           SELECT 
                             p.id,
                             p.uid,
                             p.tid,
                             p.order_id,
                             p.sale_id,
                             p.outcome_currency_id,
                             p.income_currency_id,
                             p.status,
                             o.tokens_locked
                           FROM \`${schema}\`.\`${table}\` p
                           LEFT JOIN \`${applogic}\`.\`ieo_orders\` o
                           ON p.order_id = o.id
                           ${whereString}
                           LIMIT ${limit} OFFSET ${offset}
                            ;`);
    return result;
  }

  static async findSale(conditions) {
    const conditionString = Object.entries(conditions)
        .filter(([key, value]) => !!value)
        .map(([key, value], index) => {
          if (!Array.isArray(value)) value = [value];
          value = value.map(el => typeof(el) === 'number' ? el : `'${el}'`);
          return `${index === 0 ? '' : 'AND '}\`${key}\` IN (${value})`;
        }).join(' ');
    const whereString = conditionString ? `WHERE ${conditionString}` : '';
    const result =  await db.query(`SELECT sale_id 
                           FROM \`${schema}\`.\`${table}\` p
                           ${whereString}
                           LIMIT ${1} OFFSET ${0};`);
    return result[0];
  }

  static async findLast(conditions) {
    const conditionString = Object.entries(conditions).map(([key, value], index) => {
      if (!Array.isArray(value)) value = [value];
      value = value.map(el => typeof(el) === 'number' ? el : `'${el}'`);
      if (key === 'active_from') return `${index === 0 ? '' : 'AND '} \`${key}\` < ${value[0]}`;
      return `${index === 0 ? '' : 'AND '}\`${key}\` IN (${value})`;
    }).join(' ');
    const whereString = conditionString ? `WHERE ${conditionString}` : '';
    const result =  await db.query(`SELECT * 
                          FROM \`${schema}\`.\`${table}\`
                          ${whereString}
                          ORDER BY active_from DESC LIMIT 1
                          ;`);
    return !!result[0] ? JSON.parse(result[0].commissions) : [];
  }

  static async count(conditions) {
    const conditionString = Object.entries(conditions).map(([key, value], index) => {
      if (!Array.isArray(value)) value = [value];
      value = value.map(el => typeof(el) === 'number' ? el : `'${el}'`);
      return `${index === 0 ? '' : 'AND '}\`${key}\` IN (${value})`;
    }).join(' ');
    const whereString = conditionString ? `WHERE ${conditionString}` : '';
    const result =  await db.query(`SELECT count(*) 
                           FROM \`${schema}\`.\`${table}\`
                           ${whereString}
                            ;`);
    return result[0]['count(*)'];
  }

  static async update(fields, condition) {
    const parse = (arg) => Object.entries(arg)
      .map(([key, val]) => (val = typeof val === 'string' && val !== 'NULL' ? `"${val}"` : val, [key, val]))
      .map(([key, val]) => (key = `\`${key}\``, [key, val]))
      .map(el => el.toString().replace(',', ' = '));

    const query = `UPDATE \`${schema}\`.\`${table}\` SET ${parse(fields)} WHERE ${parse(condition).toString().replace(',', ' AND ')}`;
    return db.query(query);
  }
}

module.exports = Purchase;
