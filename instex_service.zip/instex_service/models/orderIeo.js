const applogicService = require('../services/applogicService');

class OrderIeo {
    constructor({uid, sale, amount, outcome_currency_id}) {
        this.uid = uid;
        this.sale = sale;
        this.contribution = amount;
        this.outcome_currency_id = outcome_currency_id;
    }

    async createWithId() {
        let order;
        try {
            order = await applogicService.createOrder({
                uid: this.uid,
                quote_unit: this.outcome_currency_id,
                contribution: `${this.contribution}`,
                sale: this.sale
            });
            return order;
        } catch (err) {
            if (err.message != "") throw err;
        }

    }
}

module.exports = OrderIeo;
