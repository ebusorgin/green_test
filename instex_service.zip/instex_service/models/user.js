const db = require('../lib/db');
const _ = require('lodash');

const schema = `${process.env.DB_PREFIX ? process.env.DB_PREFIX + '-' : ''}barong_production`;
const table = 'users';

class User {

  static async find(conditions, limit = 10, offset = 0) {
    const conditionString = Object.entries(conditions).map(([key, value], index) => {
      if (!Array.isArray(value)) value = [value];
      value = value.map(el => typeof(el) === 'number' ? el : `'${el}'`);
      return `${index === 0 ? '' : 'AND '}\`${key}\` IN (${value})`;
    }).join(' ');
    const whereString = conditionString ? `WHERE ${conditionString}` : '';
    const result =  await db.query(`SELECT * 
                           FROM \`${schema}\`.\`${table}\`
                           ${whereString}
                           LIMIT ${limit} OFFSET ${offset}
                            ;`);
    return result;
  }

  static async count(conditions) {
    const conditionString = Object.entries(conditions).map(([key, value], index) => {
      if (!Array.isArray(value)) value = [value];
      value = value.map(el => typeof(el) === 'number' ? el : `'${el}'`);
      return `${index === 0 ? '' : 'AND '}\`${key}\` IN (${value})`;
    }).join(' ');
    const whereString = conditionString ? `WHERE ${conditionString}` : '';
    const result =  await db.query(`SELECT count(*) 
                           FROM \`${schema}\`.\`${table}\`
                           ${whereString}
                            ;`);
    return result[0]['count(*)'];
  }
}

module.exports = User;
