const peatioService = require('../services/peatioService');
const barongService = require('../services/barongService');

const schema = `${process.env.DB_PREFIX ? process.env.DB_PREFIX + '-' : ''}peatio_production`;
const table = 'orders';
class Order {
    constructor({uid, amount, outcome_currency_id, income_currency_id, target, orderType}) {
        this.uid = uid;
        this.amount = amount;
        this.outcomeCurrencyId = outcome_currency_id;
        this.incomeCurrencyId = income_currency_id;
        this.target = target; // TODO Target income / outcome 
        this.side = "buy";
        this.orderType = orderType || "market";
        this.markets = [];
    }

    async fetchMarkets() {
      let markets = await peatioService.getMarkets({
        base_unit : `${this.incomeCurrencyId}`,
        quote_unit : `${this.outcomeCurrencyId}`
      });
      markets = markets.filter(el => el.id === `${this.incomeCurrencyId}${this.outcomeCurrencyId}`); // Remove after filtration in Peatio is repaired


      if(!markets.length) {
          this.side = "sell";
          markets = await peatioService.getMarkets({
              quote_unit : `${this.incomeCurrencyId}`,
              base_unit : `${this.outcomeCurrencyId}`
          });
          markets = markets.filter(el => el.id === `${this.incomeCurrencyId}${this.outcomeCurrencyId}`);
      }

      this.markets = markets;
    }

    async fetchCurrencies() {
        this.currencies = await peatioService.getCurrencies();
    }

    async create() {
        await this.fetchMarkets();
        if(!this.markets.length) throw new Error("No availiable markets");
        await this.fetchCurrencies();

        let order, depth, proposals, total, session;
        while (true) {
            try {
                session = await barongService.createSession(this.uid);
                depth = await peatioService.getDepth(this.markets[0].id);
                proposals = this.side === "buy" ? (depth.asks || []) : (depth.bids || []);
                total = this.getCumulativeTotal(this.amount, proposals);
                total = this.applyBasefactor(total, this.markets[0]);

                order = await peatioService.createOrder({
                    session: session,
                    market: this.markets[0].id,
                    side: this.side,
                    volume: total,
                    ord_type: this.orderType,
                    // price: this.amount / total,
                });
                return order;
            } catch (err) {
                if(err.message != "") throw err;
            }
        }
    }

    getCumulativeTotal(amount, proposals) {
        if(!proposals.length || (proposals[0].length < 2)) throw Error("Invalid market depth");
        let sum = amount;
        let total = 0;

        for(let proposal of proposals) {
            if (!sum) break;

            if (sum <= (+proposal[0] * +proposal[1])) {
                total += sum/(+proposal[0]);
                sum = 0;
            } else {
                total += +proposal[1];
                sum -= (+proposal[0] * +proposal[1]);
            }
        }

        if(sum != 0) throw new Error("Not enough liquidity");
        return total;
    }

    applyBasefactor(value, { amount_precision = 8 }) {
        const base_factor = Math.pow(10, amount_precision);
        const result = Math.floor(value * base_factor) / base_factor;
        return `${result}`;
    }


    static async find(conditions, limit = 10, offset = 0) {
        const conditionString = Object.entries(conditions)
          .filter(([key, value]) => !!value)
          .map(([key, value], index) => {
            if (!Array.isArray(value)) value = [value];
            value = value.map(el => typeof(el) === 'number' ? el : `'${el}'`);
            return `${index === 0 ? '' : 'AND '}\`${key}\` IN (${value})`;
          }).join(' ');
        const whereString = conditionString ? `WHERE ${conditionString}` : '';
        const result =  await db.query(`SELECT * 
                               FROM \`${schema}\`.\`${table}\`
                               ${whereString}
                               LIMIT ${limit} OFFSET ${offset}
                                ;`);
        return result;
    }
}

module.exports = Order;
