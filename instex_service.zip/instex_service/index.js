require('console-stamp')(console, { pattern: 'dd/mm/yyyy HH:MM:ss.l' });
const express = require('express');
const router = require('./routes');
const MQListener = require('./lib/MQListener');
const DBTools = require('./lib/DBTools');
const app = express();

app.set('view engine', 'ejs');
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(async (req, res, next) => {
	console.log(req.method, req.url);
	await next();
});

app.use('/api/v1', router);

(async () => {
	await DBTools.init();
	await MQListener.listen();
	await app.listen(process.env.PORT, () =>
		console.log(`Server listen ${process.env.PORT} port`)
	);
})();
process.on('uncaughtException', function (err)
{
	console.log('<- UNCAUGHT ERROR START ------------------------------------------------------------------------------>');
	console.log(new Date());
	console.log(err.message);
	console.log(err.stack);
	console.log('<- UNCAUGHT ERROR END -------------------------------------------------------------------------------->');
});