const instexController = require("./instexController");

module.exports = {
  instexController
};
