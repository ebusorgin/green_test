const instexService = require('../services/instexService');
const paytoolsService = require('../services/paytoolsService');
const path = require('path');
const fs = require('fs')
const {promisify} = require('util')
const {verifyPaynetJWS} = require('../lib/JWTHandler')
const logger = require('../lib/logger')
const db = require('../lib/db');
const User = require("../models/user");
const {PaytoolsError} = require("../common/customErrors");
const {ValidationError} = require("../common/customErrors");

const redirect_url_base = `${process.env.SELF_URL}/api/v2/instex/private/orders`;
const stateMap = {
    "orderFailure": "Your payment was accepted, but a problem with placing order occured. Your deposit stays on your exchange account in the original currency.",
    "ccDeclined": "Your credit card payment was declined."
};
const readFileAsync = promisify(fs.readFile)

class InstexController {
    static async PaymentToCardRedirect(req, res) {

    }
    static async PaymentToCard(req, res) {

        const ipaddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        const session = req.session;
        const payload = req.body;
        payload.session  = session
        payload.ipaddress  = ipaddress
        let state
        try {
            state = await paytoolsService.PaymentToCard(payload);
        } catch (err) {
            console.log(err);
            res.send(500, err.message);
            return;
        }
        res.status(200).send(JSON.stringify(state.data));
    }
    static async reversal(req, res) {
        const jws = req.body.message
        const payload = verifyPaynetJWS(jws)
        console.log("REVERSAL START",payload)
        let reversalInt = parseFloat(payload.amount)
        let amount = reversalInt + (reversalInt * (3.2 / 100) + 0.1)
        await db.query(`insert into instex_service.reversal (amount,uid) VALUES ('${amount}','${payload.uid}') ON DUPLICATE KEY UPDATE amount=amount+'${amount}'`)
        await db.query(`insert into instex_service.reversal_logs (uid,amount,type) VALUES ('${payload.uid}','${amount}','reversal') `)
        res.status(200).send('accept');
    }
    static async getReversal(req, res) {
        const jws = req.body.message
        const payload = verifyPaynetJWS(jws)
        let skip = 0;
        let limit = 20;
        if (payload.hasOwnProperty('skip')){
            skip = payload.skip;
        }
        if (payload.hasOwnProperty('limit')){
            limit = payload.limit;
        }
        let logReversal = await db.query(`SELECT * FROM into instex_service.reversal_logs WHERE uid='${payload.uid}'  LIMIT ${skip},${limit}`)
        let actualReversal = await db.query(`SELECT * FROM into instex_service.reversal WHERE uid='${payload.uid}' `)
        let result = {logReversal,actualReversal}
        res.status(200).send(JSON.stringify(result));
    }

    static async newPurchase(req, res) {
        const ipaddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        const session = req.session;
        const payload = req.body;
        const {outcomeCurrencyId, incomeCurrencyId, amount, style} = payload;

        let url, tid;
        try {
            switch (req.body.type) {
                case("ccPurchase") : {
                    const response = await instexService.initializeCcPurchase({session, payload, ipaddress});
                    url = response.url;
                    tid = response.tid;
                    break;
                }

                case("instantPurchase") : {
                    url = await instexService.initializeInstPurchase({session, payload, ipaddress});
                    break;

                }
                default: {
                    throw new Error("Invalid Type");
                }
            }
        } catch (err) {
            if (err.response.data&&err.response.data.hasOwnProperty('errors')) res.status(422).send(JSON.stringify(err.response.data));
            else res.status(500).send(err.message);
            return;
        }

        res.status(200).send({url, tid});
    }


    static async newTransfer(req, res) {
        const jws = req.body.message
        const payload = verifyPaynetJWS(jws)

        try {
            const ipaddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
            logger.log({level: 'info', message: payload, ipaddress})

            const result = await instexService.initializeTransfer({payload});
            console.log('TRY',result)
            res.status(200).send('Order successfully created');
        } catch (error) {
            logger.log({level: 'error', message: error})
            if (error instanceof ValidationError) res.status(422).send(error.message);
            else res.status(500).send(error.message);
        }
    }

    static async getPurchaseStatusInternal(req, res) {

        // TODO: Put IEO logic in a separate method
        if (!req.params.id) {
            res.status(422).send('Please provide orderId')
            return;
        }

        const id = req.params.id;
        let {
            sell_amount,
            sell_currency,
            buy_amount,
            buy_currency,
            style
        } = req.query;
        const session = req.session;
        const root = path.join(__dirname, '../views/purchaseStatus');
        const payload = {
            session
        }

        if (id.startsWith("TID")) {
            payload.tid = id;
        } else if (!isNaN(id)) {
            payload.order_id = id;
        } else {
            throw new Error("False request");
        }

        let status;
        try {
            const res = await instexService.getPurchase(payload)
            status = res.status;
            buy_amount = res.origin_volume - res.fee;
        } catch (err) {
            console.log(err);
            if (err instanceof ValidationError) res.status(422).send(err.message);
            else res.status(500).send(err.message);
            return;
        }

        // distinguish states
        switch (status) {
            case 'ccInit':
            case 'ccAccepted': {
                console.log('Fire ccInit/ccAccepted');
                const wait = (await readFileAsync(`${root}/wait.html`)).toString();
                const dynamicUrl = `${redirect_url_base}/${payload.tid}?sell_amount=${sell_amount}&sell_currency=${sell_currency}&buy_amount=${buy_amount}&buy_currency=${buy_currency}&style=${style}&timestamp=${Date.now()}`;
                const result = wait.replace('<<DYNAMIC_URL>>', dynamicUrl);

                res.send(result);
                break;
            }

            case 'orderComplete': {
                console.log('Fire orderComplete');
                res.render('purchaseStatus/accept', {
                    sell_amount: parseFloat(sell_amount).toFixed(8),
                    sell_currency: sell_currency.toUpperCase(),
                    buy_amount: parseFloat(buy_amount).toFixed(8),
                    buy_currency: buy_currency.toUpperCase()
                })
                break;
            }


            case 'orderFailure':
            case 'ccDeclined':
            case 'rejected':
            case 'canceled': {
                console.log('Fire canceled/rejected/ccDeclined/orderFailure');
                res.render('purchaseStatus/decline', {message: stateMap[status]});
                break;
            }

            default: {
                console.log('Fire default');
                res.send(500);
                break;
            }
        }
    }

    static async getPayment(req, res) {
        if (!req.params.tid) {
            res.status(422).send('Please provide id');
            return;
        } else if (Number.isInteger(req.params.tid)) {
            res.status(422).send('Id must be a number');
            return;
        }

        const id = req.params.tid;
        const session = req.session;
        const payload = {session};

        if (id.startsWith("TID")) {
            payload.tid = id;
        } else if (!isNaN(id)) {
            payload.order_id = id;
        } else {
            throw new Error("False request");
        }

        try {
            const payment = await instexService.getPurchase(payload);
            res.send(payment);
        } catch (err) {
            console.log(err);
            res.send(500, err.message);
        }
    }

    static async getCcPurchaseStatusExternal(req, res) {
        const data = req.body;
        const tid = data.merchant_order;

        const {
            sell_amount,
            sell_currency,
            buy_amount,
            buy_currency,
            style
        } = req.query;

        let state;
        try {
            state = await paytoolsService.handleRedirect(data);
        } catch (err) {
            console.log(err);
            res.send(500, err.message);
            return;
        }

        res.redirect(301, `${redirect_url_base}/${tid}?sell_amount=${sell_amount}&sell_currency=${sell_currency}&buy_amount=${buy_amount}&buy_currency=${buy_currency}&style=${style}`);
    }


}

module.exports = InstexController;
