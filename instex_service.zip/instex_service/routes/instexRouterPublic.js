const {instexController} = require("../controllers");
const router = require('express').Router();
const {transactionController} = require("../controllers");

router.get('/payment_to_card_redirect', instexController.PaymentToCardRedirect);

module.exports = router;
