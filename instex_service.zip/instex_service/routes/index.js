const router = require('express').Router();
const instexRouterAdmin = require("./instexRouterAdmin");
const instexRouterPrivate = require("./instexRouterPrivate");
const instexRouterPublic = require("./instexRouterPublic");

router.use("/admin", instexRouterAdmin);
router.use("/private", instexRouterPrivate);
router.use("/public", instexRouterPublic);

module.exports = router;