const router = require('express').Router();
const { instexController } = require('../controllers');
const barongJwt = require('node-auth-barong');
const barongJwtPublicKey = Buffer.from(
	process.env.BARONG_JWT_PUBLIC_KEY,
	'base64'
).toString('utf-8');

router.use('/', barongJwt({ barongJwtPublicKey }));
// router.get('/commissions', instexController.getCommissions);
// router.post('/commissions/new', instexController.setCommission);

module.exports = router;