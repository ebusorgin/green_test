const router = require('express').Router();
const { instexController } = require('../controllers');
const barongJwt = require('node-auth-barong');
const barongJwtPublicKey = Buffer.from(
	process.env.BARONG_JWT_PUBLIC_KEY,
	'base64'
).toString('utf-8');

router.post('/create_order', instexController.newTransfer);
router.post('/reversal', instexController.reversal);


router.use('/', barongJwt({ barongJwtPublicKey }));
router.get('/payments/:tid', instexController.getPayment);
router.get('/orders/:id', instexController.getPurchaseStatusInternal);
router.post('/orders', instexController.getCcPurchaseStatusExternal);
router.post('/orders/new', instexController.newPurchase);
router.post('/get_reversal', instexController.getReversal);
router.post('/payment_to_card', instexController.PaymentToCard);


module.exports = router;
